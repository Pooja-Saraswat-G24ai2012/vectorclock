import requests
import sys

def run_client():
    if len(sys.argv) < 3:
        print("Usage: python client.py <node_url> <action> [args]")
        return

    endpoint = sys.argv[1]
    operation = sys.argv[2]

    if operation == 'read':
        if len(sys.argv) < 4:
            print("Usage: python client.py <node_url> read <key>")
            return
        lookup_key = sys.argv[3]
        outcome = requests.get(f"{endpoint}/read/{lookup_key}")
        print(outcome.json())

    elif operation == 'write':
        if len(sys.argv) < 5:
            print("Usage: python client.py <node_url> write <key> <value>")
            return
        store_key = sys.argv[3]
        store_value = sys.argv[4]
        outcome = requests.post(f"{endpoint}/write", json={'key': store_key, 'value': store_value})
        print(outcome.json())

    else:
        print("Unknown action. Use 'read' or 'write'.")

if __name__ == '__main__':
    run_client()
