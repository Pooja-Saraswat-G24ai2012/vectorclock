import os
import json
import threading
from flask import Flask, request, jsonify

app = Flask(__name__)

class ClockVector:
    def __init__(self, self_id, total_nodes):
        self.idx = self_id
        self.vector = [0] * total_nodes

    def tick(self):
        self.vector[self.idx] += 1

    def merge(self, incoming):
        self.vector = [max(a, b) for a, b in zip(self.vector, incoming)]

    def __repr__(self):
        return json.dumps(self.vector)

class DistributedKV:
    def __init__(self, self_id, total_nodes):
        self.node_id = self_id
        self.clock = ClockVector(self_id, total_nodes)
        self.db = {}
        self.queue = []
        self.mutex = threading.Lock()

    def local_write(self, key, value):
        with self.mutex:
            self.clock.tick()
            self.db[key] = value
            return {
                'key': key,
                'value': value,
                'vector_clock': self.clock.vector,
                'origin_id': self.node_id
            }

    def receive_update(self, msg):
        with self.mutex:
            if self._can_apply(msg):
                self._apply(msg)
                self._drain_queue()
            else:
                self.queue.append(msg)

    def _apply(self, msg):
        self.db[msg['key']] = msg['value']
        self.clock.merge(msg['vector_clock'])

    def _can_apply(self, msg):
        for i, remote in enumerate(msg['vector_clock']):
            if i != msg['origin_id'] and self.clock.vector[i] < remote:
                return False
        return True

    def _drain_queue(self):
        applied = True
        while applied:
            applied = False
            for pending in list(self.queue):
                if self._can_apply(pending):
                    self._apply(pending)
                    self.queue.remove(pending)
                    applied = True

# Set up instance
replica_id = int(os.getenv('NODE_ID', 0))
replica_store = DistributedKV(replica_id, 3)

@app.route('/write', methods=['POST'])
def endpoint_write():
    content = request.get_json()
    result = replica_store.local_write(content['key'], content['value'])
    return jsonify(result)

@app.route('/replicate', methods=['POST'])
def endpoint_replicate():
    msg = request.get_json()
    replica_store.receive_update(msg)
    return jsonify({'status': 'received'})

@app.route('/read/<key>', methods=['GET'])
def endpoint_read(key):
    return jsonify({
        'key': key,
        'value': replica_store.db.get(key),
        'vector_clock': replica_store.clock.vector
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
